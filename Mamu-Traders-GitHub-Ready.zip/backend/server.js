import express from 'express';
import cors from 'cors';
import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import path from 'path';
import crypto from 'crypto';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET || 'change-this-secret-in-production';
const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || 'admin@mamutraders.in').toLowerCase();
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'ChangeMe123!';
const RAZORPAY_KEY_ID = process.env.RAZORPAY_KEY_ID || '';
const DB_PATH = process.env.DATABASE_PATH || path.join(__dirname, 'data', 'mamu-traders.db');
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
app.use(cors());
app.use(express.json({limit:'1mb'}));

db.exec(`
CREATE TABLE IF NOT EXISTS products (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, cat TEXT NOT NULL,
 price INTEGER NOT NULL, old INTEGER NOT NULL, icon TEXT DEFAULT '🛍️',
 rating REAL DEFAULT 4.5, reviews INTEGER DEFAULT 0, desc TEXT DEFAULT '',
 image TEXT DEFAULT '', stock INTEGER DEFAULT 100, active INTEGER DEFAULT 1,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
 password TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, customer_name TEXT NOT NULL,
 phone TEXT, address TEXT, total INTEGER NOT NULL, status TEXT DEFAULT 'Placed',
 payment_method TEXT DEFAULT 'COD', payment_status TEXT DEFAULT 'Pending',
 payment_id TEXT DEFAULT '', items_json TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS admins (
 id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT UNIQUE NOT NULL, password TEXT NOT NULL,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);

const seed = [
['Premium Everyday Shirt','Fashion',799,999,'👕',4.8,124,'Comfortable everyday wear with a clean, versatile look.'],
['Classic Travel Bag','Accessories',1199,1499,'🎒',4.7,89,'Spacious and practical for daily travel, work and short trips.'],
['Home Utility Set','Home',499,699,'🏠',4.6,201,'Useful everyday essentials designed to keep your home organized.'],
['Smart Daily Accessories','Accessories',599,799,'⌚',4.8,76,'Simple accessories that add convenience to your daily routine.'],
['Comfort Casual Wear','Fashion',899,1099,'👔',4.7,142,'Easy-going style made for everyday comfort and movement.'],
['Premium Home Organizer','Home',699,899,'🧺',4.9,65,'A neat storage solution for everyday household items.'],
['Value Fashion Combo','Fashion',999,1299,'🧢',4.6,98,'A value-packed fashion combo for your everyday wardrobe.'],
['Useful Travel Essentials','Accessories',749,949,'🧳',4.8,113,'Travel-ready essentials that make your journey easier.']
];
if (db.prepare('SELECT COUNT(*) c FROM products').get().c === 0) {
  const ins=db.prepare('INSERT INTO products(name,cat,price,old,icon,rating,reviews,desc) VALUES (?,?,?,?,?,?,?,?)');
  db.transaction(rows=>rows.forEach(r=>ins.run(...r)))(seed);
}

async function ensureAdmin(){
  const exists=db.prepare('SELECT id FROM admins WHERE email=?').get(ADMIN_EMAIL);
  if(!exists){
    const hash=await bcrypt.hash(ADMIN_PASSWORD,10);
    db.prepare('INSERT INTO admins(email,password) VALUES(?,?)').run(ADMIN_EMAIL,hash);
    console.log(`Admin created: ${ADMIN_EMAIL}`);
  }
}
const publicUser = id => db.prepare('SELECT id,name,email,created_at FROM users WHERE id=?').get(id);
const signUser = id => jwt.sign({id,type:'user'},JWT_SECRET,{expiresIn:'7d'});
const signAdmin = id => jwt.sign({id,type:'admin'},JWT_SECRET,{expiresIn:'12h'});

function auth(req,res,next){
  const h=req.headers.authorization||'';
  if(!h.startsWith('Bearer ')) return res.status(401).json({error:'Login required'});
  try { const p=jwt.verify(h.slice(7),JWT_SECRET); if(p.type!=='user') throw new Error(); req.user=p; next(); }
  catch { return res.status(401).json({error:'Invalid or expired token'}); }
}
function adminAuth(req,res,next){
  const h=req.headers.authorization||'';
  if(!h.startsWith('Bearer ')) return res.status(401).json({error:'Admin login required'});
  try { const p=jwt.verify(h.slice(7),JWT_SECRET); if(p.type!=='admin') throw new Error(); req.admin=p; next(); }
  catch { return res.status(401).json({error:'Invalid or expired admin token'}); }
}

app.get('/api/health',(req,res)=>res.json({ok:true,service:'Mamu Traders API'}));
app.get('/api/config',(req,res)=>res.json({razorpayEnabled:!!RAZORPAY_KEY_ID,razorpayKeyId:RAZORPAY_KEY_ID}));
app.get('/api/products',(req,res)=>{
  let {q,cat,sort,all}=req.query;
  let sql='SELECT * FROM products WHERE 1=1',args=[];
  if(all!=='1') sql+=' AND active=1';
  if(q){sql+=' AND (LOWER(name) LIKE ? OR LOWER(cat) LIKE ?)';const x='%'+q.toLowerCase()+'%';args.push(x,x)}
  if(cat&&cat!=='All'){sql+=' AND cat=?';args.push(cat)}
  if(sort==='low')sql+=' ORDER BY price ASC'; else if(sort==='high')sql+=' ORDER BY price DESC'; else sql+=' ORDER BY id DESC';
  res.json(db.prepare(sql).all(...args));
});
app.get('/api/products/:id',(req,res)=>{const p=db.prepare('SELECT * FROM products WHERE id=? AND active=1').get(req.params.id);p?res.json(p):res.status(404).json({error:'Product not found'})});

app.post('/api/auth/register',async(req,res)=>{
  try{const {name,email,password}=req.body;if(!name||!email||!password||password.length<6)return res.status(400).json({error:'Name, email and password (6+ chars) are required'});
  const hash=await bcrypt.hash(password,10);const r=db.prepare('INSERT INTO users(name,email,password) VALUES(?,?,?)').run(name,email.toLowerCase(),hash);
  res.status(201).json({token:signUser(r.lastInsertRowid),user:publicUser(r.lastInsertRowid)})}
  catch(e){res.status(409).json({error:'Email is already registered'})}
});
app.post('/api/auth/login',async(req,res)=>{
  const {email,password}=req.body;const u=db.prepare('SELECT * FROM users WHERE email=?').get((email||'').toLowerCase());
  if(!u||!(await bcrypt.compare(password||'',u.password)))return res.status(401).json({error:'Invalid email or password'});
  res.json({token:signUser(u.id),user:publicUser(u.id)});
});
app.get('/api/me',auth,(req,res)=>res.json({user:publicUser(req.user.id)}));

app.post('/api/orders',auth,(req,res)=>{
  const {items,address,phone,paymentMethod='COD'}=req.body;
  if(!Array.isArray(items)||!items.length)return res.status(400).json({error:'Cart is empty'});
  let total=0;const clean=[];
  for(const i of items){
    const p=db.prepare('SELECT * FROM products WHERE id=? AND active=1').get(i.id);
    if(!p)continue;
    const qty=Math.max(1,Math.min(99,Number(i.qty)||1));
    if(qty>p.stock)return res.status(400).json({error:`Only ${p.stock} units available for ${p.name}`});
    total+=p.price*qty;clean.push({id:p.id,name:p.name,price:p.price,qty});
  }
  if(!clean.length)return res.status(400).json({error:'No valid products'});
  if(!address||!phone)return res.status(400).json({error:'Delivery address and mobile number are required'});
  const u=publicUser(req.user.id);
  const r=db.prepare('INSERT INTO orders(user_id,customer_name,phone,address,total,payment_method,payment_status,items_json) VALUES(?,?,?,?,?,?,?,?)')
    .run(req.user.id,u.name,phone,address,total,paymentMethod,paymentMethod==='COD'?'Pending':'Pending',JSON.stringify(clean));
  for(const i of clean)db.prepare('UPDATE products SET stock=MAX(0,stock-?) WHERE id=?').run(i.qty,i.id);
  res.status(201).json({orderId:r.lastInsertRowid,total,status:'Placed',paymentStatus:'Pending'});
});
app.get('/api/orders',auth,(req,res)=>{
  const rows=db.prepare('SELECT id,total,status,payment_method,payment_status,payment_id,items_json,address,created_at FROM orders WHERE user_id=? ORDER BY id DESC').all(req.user.id);
  res.json(rows.map(x=>({...x,items:JSON.parse(x.items_json)})));
});

/* Admin */
app.post('/api/admin/login',async(req,res)=>{
  const {email,password}=req.body;const a=db.prepare('SELECT * FROM admins WHERE email=?').get((email||'').toLowerCase());
  if(!a||!(await bcrypt.compare(password||'',a.password)))return res.status(401).json({error:'Invalid admin credentials'});
  res.json({token:signAdmin(a.id),admin:{email:a.email}});
});
app.get('/api/admin/me',adminAuth,(req,res)=>{const a=db.prepare('SELECT email FROM admins WHERE id=?').get(req.admin.id);res.json({ok:true,admin:a||{}});});

app.get('/api/admin/stats',adminAuth,(req,res)=>{
  const revenue=db.prepare("SELECT COALESCE(SUM(total),0) revenue FROM orders WHERE status!='Cancelled'").get().revenue;
  const orders=db.prepare("SELECT COUNT(*) c FROM orders").get().c;
  const customers=db.prepare("SELECT COUNT(*) c FROM users").get().c;
  const products=db.prepare("SELECT COUNT(*) c FROM products WHERE active=1").get().c;
  const recentOrders=db.prepare("SELECT id,customer_name,total,status,created_at FROM orders ORDER BY id DESC LIMIT 6").all();
  const rows=db.prepare("SELECT items_json FROM orders WHERE status!='Cancelled'").all();
  const agg={};
  for(const row of rows){for(const item of JSON.parse(row.items_json||'[]')){if(!agg[item.id])agg[item.id]={name:item.name,sold:0,revenue:0};agg[item.id].sold+=Number(item.qty)||0;agg[item.id].revenue+=(Number(item.qty)||0)*(Number(item.price)||0)}}
  const topProducts=Object.values(agg).sort((a,b)=>b.sold-a.sold).slice(0,6);
  res.json({revenue,orders,customers,products,recentOrders,topProducts});
});
app.get('/api/admin/customers',adminAuth,(req,res)=>{
  const rows=db.prepare(`
    SELECT u.id,u.name,u.email,u.created_at,
           COUNT(o.id) orders,
           COALESCE(SUM(CASE WHEN o.status!='Cancelled' THEN o.total ELSE 0 END),0) spent
    FROM users u LEFT JOIN orders o ON o.user_id=u.id
    GROUP BY u.id ORDER BY u.id DESC
  `).all();
  res.json(rows);
});

app.get('/api/admin/products',adminAuth,(req,res)=>res.json(db.prepare('SELECT * FROM products ORDER BY id DESC').all()));
app.post('/api/admin/products',adminAuth,(req,res)=>{
  const {name,cat,price,old,icon='🛍️',rating=4.5,reviews=0,desc='',image='',stock=100,active=1}=req.body;
  if(!name||!cat||Number(price)<0)return res.status(400).json({error:'Name, category and valid price are required'});
  const r=db.prepare('INSERT INTO products(name,cat,price,old,icon,rating,reviews,desc,image,stock,active) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
    .run(name,cat,Number(price),Number(old||price),icon,Number(rating),Number(reviews),desc,image,Number(stock),active?1:0);
  res.status(201).json(db.prepare('SELECT * FROM products WHERE id=?').get(r.lastInsertRowid));
});
app.put('/api/admin/products/:id',adminAuth,(req,res)=>{
  const p=db.prepare('SELECT * FROM products WHERE id=?').get(req.params.id);if(!p)return res.status(404).json({error:'Product not found'});
  const v={...p,...req.body};
  db.prepare('UPDATE products SET name=?,cat=?,price=?,old=?,icon=?,rating=?,reviews=?,desc=?,image=?,stock=?,active=? WHERE id=?')
    .run(v.name,v.cat,Number(v.price),Number(v.old||v.price),v.icon||'🛍️',Number(v.rating||4.5),Number(v.reviews||0),v.desc||'',v.image||'',Number(v.stock||0),v.active?1:0,p.id);
  res.json(db.prepare('SELECT * FROM products WHERE id=?').get(p.id));
});
app.delete('/api/admin/products/:id',adminAuth,(req,res)=>{
  const r=db.prepare('UPDATE products SET active=0 WHERE id=?').run(req.params.id);res.json({ok:r.changes>0});
});
app.get('/api/admin/orders',adminAuth,(req,res)=>{
  const rows=db.prepare('SELECT id,user_id,customer_name,phone,address,total,status,payment_method,payment_status,payment_id,items_json,created_at FROM orders ORDER BY id DESC').all();
  res.json(rows.map(x=>({...x,items:JSON.parse(x.items_json)})));
});
app.patch('/api/admin/orders/:id',adminAuth,(req,res)=>{
  const allowed=['Placed','Confirmed','Packed','Shipped','Out for Delivery','Delivered','Cancelled'];
  const {status,paymentStatus}=req.body;
  if(status && !allowed.includes(status))return res.status(400).json({error:'Invalid order status'});
  db.prepare('UPDATE orders SET status=COALESCE(?,status),payment_status=COALESCE(?,payment_status) WHERE id=?').run(status||null,paymentStatus||null,req.params.id);
  res.json(db.prepare('SELECT id,total,status,payment_status FROM orders WHERE id=?').get(req.params.id));
});

/* Simple Razorpay-ready order endpoint. Install/use Razorpay keys in production. */
app.post('/api/payments/order',auth,async(req,res)=>{
  if(!RAZORPAY_KEY_ID)return res.status(503).json({error:'Online payment is not configured. Use COD or add Razorpay keys.'});
  return res.status(501).json({error:'Razorpay server integration hook is ready; add the Razorpay secret and SDK before accepting live payments.'});
});

app.use(express.static(path.join(__dirname,'..')));
app.get('/{*splat}',(req,res)=>{ if(!req.path.startsWith('/api/')) res.sendFile(path.join(__dirname,'..','index.html')); });

ensureAdmin().then(()=>app.listen(PORT,()=>console.log(`Mamu Traders running on http://localhost:${PORT}`)));
