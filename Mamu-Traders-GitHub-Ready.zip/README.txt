MAMU TRADERS — Meesho-style full-stack ecommerce

WHAT IS INCLUDED
- Responsive marketplace storefront
- Search, categories, sorting
- Cart + wishlist
- Customer registration/login
- Server-side orders + stock tracking
- Customer order history
- Admin dashboard at /admin.html
- Product add/edit/hide + stock management
- Order status + payment status management
- COD checkout
- Razorpay integration hook
- SQLite database
- Render deployment configuration
- Express 5 catch-all route fixed for production
- Database path can be supplied with DATABASE_PATH for persistent storage

LOCAL RUN
Requirements: Node.js 18+

  cd backend
  npm install
  npm start

Open http://localhost:4000
Admin: http://localhost:4000/admin.html

DEFAULT ADMIN (CHANGE IN PRODUCTION)
Email: admin@mamutraders.in
Password: ChangeMe123!

PRODUCTION RECOMMENDATION
Deploy the complete project as one Node web service on Render/Railway/etc.
The backend serves the frontend, so the public site and /admin.html use one origin.

Required environment variables:
- JWT_SECRET = a long random secret
- ADMIN_EMAIL = your admin email
- ADMIN_PASSWORD = a strong admin password
- DATABASE_PATH = optional; defaults to backend/data/mamu-traders.db
- RAZORPAY_KEY_ID = optional; online payment remains disabled until server-side Razorpay verification is implemented

PERSISTENT DATABASE
SQLite needs persistent storage. On a host with a persistent disk, set:
DATABASE_PATH=/opt/render/project/src/backend/data/mamu-traders.db
and mount the persistent disk at:
/opt/render/project/src/backend/data

If you deploy without persistent storage, the SQLite database can be lost on redeploy/restart.

NETLIFY
Netlify can host the frontend separately, but then set window.MAMU_API to the deployed backend URL.
For the simplest setup, deploy the complete project to a Node web service so the frontend and API share the same origin.

PAYMENTS
COD works immediately. The Razorpay endpoint is intentionally not enabled for live payment capture until the Razorpay secret and signature verification are added.
