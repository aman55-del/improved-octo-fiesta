const API=(window.MAMU_API||'')+'/api';
let token=localStorage.getItem('mamuAdminToken')||'';
const $=id=>document.getElementById(id);
async function api(path,opts={}){const r=await fetch(API+path,{...opts,headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{})}});const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||'Request failed');return d}
function showTab(tab){document.querySelectorAll('.tab').forEach(x=>x.hidden=true);$(tab+'Tab').hidden=false;document.querySelectorAll('.nav[data-tab]').forEach(x=>x.classList.toggle('active',x.dataset.tab===tab));if(tab==='dashboard')loadDashboard();if(tab==='products')loadProducts();if(tab==='orders')loadOrders();if(tab==='customers')loadCustomers()}
async function login(){try{const d=await api('/admin/login',{method:'POST',body:JSON.stringify({email:$('email').value,password:$('password').value})});token=d.token;localStorage.setItem('mamuAdminToken',token);$('adminEmail').textContent=d.admin.email;$('login').hidden=true;$('app').hidden=false;showTab('dashboard')}catch(e){$('loginMsg').textContent=e.message}}
function logout(){token='';localStorage.removeItem('mamuAdminToken');location.reload()}
function money(n){return '₹'+Number(n||0).toLocaleString('en-IN')}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}

async function loadDashboard(){try{const d=await api('/admin/stats');$('stats').innerHTML=[
['💰','Revenue',money(d.revenue)],['🛒','Orders',d.orders],['👥','Customers',d.customers],['📦','Active Products',d.products]
].map(x=>`<div class="stat"><span class="ico">${x[0]}</span><b>${x[2]}</b><small>${x[1]}</small></div>`).join('');
$('recentOrders').innerHTML=d.recentOrders.map(o=>`<div class="order"><div class="row"><b>#${o.id} · ${esc(o.customer_name)}</b><b>${money(o.total)}</b></div><div class="row"><span class="muted">${new Date(o.created_at).toLocaleString()}</span><span class="badge ${o.status==='Delivered'?'green':''}">${esc(o.status)}</span></div></div>`).join('')||'<p class="muted">No orders yet.</p>';
$('topProducts').innerHTML=d.topProducts.map(p=>`<div class="item"><div><b>${esc(p.name)}</b><small>${p.sold} units sold</small></div><b>${money(p.revenue)}</b></div>`).join('')||'<p class="muted">No sales yet.</p>'}catch(e){alert(e.message)}}

function newProduct(p={}){$('productForm').innerHTML=`<div class="card" style="background:#fafafa"><h2>${p.id?'Edit':'Add'} Product</h2><div class="formgrid">
<input id="pn" placeholder="Product name" value="${esc(p.name)}"><input id="pc" placeholder="Category (Fashion/Home/Accessories)" value="${esc(p.cat)}">
<input id="pp" type="number" placeholder="Price" value="${p.price??''}"><input id="po" type="number" placeholder="Old price" value="${p.old??''}">
<input id="ps" type="number" placeholder="Stock" value="${p.stock??100}"><input id="pi" placeholder="Icon emoji" value="${esc(p.icon||'🛍️')}">
<input id="pr" type="number" step=".1" placeholder="Rating" value="${p.rating??4.5}"><input id="pimg" placeholder="Image URL (optional)" value="${esc(p.image||'')}">
<textarea id="pd" placeholder="Description">${esc(p.desc||'')}</textarea></div><div class="form-actions"><button class="primary" onclick="saveProduct(${p.id||''})">Save Product</button><button class="secondary" onclick="$('productForm').innerHTML=''">Cancel</button></div></div>`}
async function saveProduct(id){const v={name:$('pn').value,cat:$('pc').value,price:+$('pp').value,old:+$('po').value,stock:+$('ps').value,icon:$('pi').value,image:$('pimg').value,rating:+$('pr').value,desc:$('pd').value};try{await api(id?'/admin/products/'+id:'/admin/products',{method:id?'PUT':'POST',body:JSON.stringify(v)});$('productForm').innerHTML='';loadProducts();loadDashboard()}catch(e){alert(e.message)}}
async function loadProducts(){try{const ps=await api('/admin/products');$('products').innerHTML=ps.map(p=>`<div class="item"><div><b>${esc(p.icon)} ${esc(p.name)}</b><small>${esc(p.cat)} · ${money(p.price)} · Stock ${p.stock} · ${p.active?'Active':'Hidden'}</small></div><div><button class="edit" onclick='newProduct(${JSON.stringify(p).replace(/</g,"\\u003c")})'>Edit</button><button class="danger" onclick="hideProduct(${p.id})">${p.active?'Hide':'Hidden'}</button></div></div>`).join('')||'<p class="muted">No products.</p>'}catch(e){alert(e.message)}}
async function hideProduct(id){if(!confirm('Hide this product?'))return;try{await api('/admin/products/'+id,{method:'DELETE'});loadProducts();loadDashboard()}catch(e){alert(e.message)}}

async function loadOrders(){try{const os=await api('/admin/orders');$('orders').innerHTML=os.map(o=>`<div class="order"><div class="row"><b>Order #${o.id}</b><b>${money(o.total)}</b></div><div class="row"><span>${esc(o.customer_name)} · ${esc(o.phone||'')}</span><span class="badge ${o.status==='Delivered'?'green':''}">${esc(o.status)}</span></div><p class="muted">${esc(o.address||'')} · ${new Date(o.created_at).toLocaleString()}</p><div class="row"><small>${o.items.map(i=>esc(i.name)+' × '+i.qty).join(', ')}</small><select onchange="updateOrder(${o.id},this.value)">${['Placed','Confirmed','Packed','Shipped','Out for Delivery','Delivered','Cancelled'].map(s=>`<option ${s===o.status?'selected':''}>${s}</option>`).join('')}</select></div><small class="muted">Payment: ${esc(o.payment_method)} · ${esc(o.payment_status)}</small></div>`).join('')||'<p class="muted">No orders yet.</p>'}catch(e){alert(e.message)}}
async function updateOrder(id,status){try{await api('/admin/orders/'+id,{method:'PATCH',body:JSON.stringify({status})});loadOrders();loadDashboard()}catch(e){alert(e.message)}}

async function loadCustomers(){try{const cs=await api('/admin/customers');$('customers').innerHTML=cs.map(c=>`<div class="customer"><div class="row"><b>${esc(c.name)}</b><span class="badge">${c.orders} orders</span></div><div class="muted">${esc(c.email)}</div><div class="row"><small>Joined ${new Date(c.created_at).toLocaleDateString()}</small><b>${money(c.spent)}</b></div></div>`).join('')||'<p class="muted">No customers yet.</p>'}catch(e){alert(e.message)}}

(async()=>{if(token){try{const d=await api('/admin/me');$('adminEmail').textContent=d.admin?.email||'';$('login').hidden=true;$('app').hidden=false;showTab('dashboard')}catch{logout()}}})();
